﻿@echo off
chcp 65001 >nul 2>&1
echo ============================================
echo   مبدل Payload تراکنش - اجرای محلی
echo ============================================
echo.

REM Try Python first (most common)
python --version >nul 2>&1
if %errorlevel% equ 0 (
    echo در حال اجرا با Python HTTP Server...
    echo آدرس: http://localhost:8080
    echo برای خروج Ctrl+C را بزنید
    echo.
    start http://localhost:8080
    python -m http.server 8080
    goto :end
)

REM Try npx serve
npx --version >nul 2>&1
if %errorlevel% equ 0 (
    echo در حال اجرا با npx serve...
    echo آدرس: http://localhost:3000
    echo.
    npx serve . -l 3000
    goto :end
)

REM Nothing available
echo خطا: Python یا Node.js یافت نشد.
echo یکی از موارد زیر را نصب کنید:
echo   - Python 3: https://python.org
echo   - Node.js:  https://nodejs.org
echo.
echo سپس این فایل را دوباره اجرا کنید.
pause

:end
